This program is a sample project for basic arithmetic operations and personal information records. It is not suitable for commercial or daily use.

Program Functions:

1) Calculator: The calculator can be used for basic arithmetic operations, such as addition, subtraction, multiplication, and division.

2) Personal Information Screen: This screen takes the entered name and surname data, decrypts the password of the record file inside, searches for the person in the list, and if it cannot find it, asks "Do you want to save it?". If the user says yes, it asks the user for the remaining necessary information and saves it, then encrypts the file again.

Important Notes:

This program is a NoSQL program and is not connected to a database.
The program is not intended for commercial or daily use. It is a sample project for educational purposes.
Translation:

Program Description:

This program is a sample project for basic arithmetic operations and personal information records. It is not suitable for commercial or daily use.

Program Functions:

1) Calculator: The calculator can be used for basic arithmetic operations, such as addition, subtraction, multiplication, and division.

2) Personal Information Screen:

This screen takes the entered name and surname data.
It decrypts the password of the record file inside.
It searches for the person in the list.
If it cannot find the person, it asks "Do you want to save it?".
If the user says yes, it asks the user for the remaining necessary information.
It saves the information and encrypts the file again.
Important Notes:

This program is a NoSQL program and is not connected to a database.
The program is not intended for commercial or daily use. It is a sample project for educational purposes.


To start the program:

Run the Başlat.bat file.
If the file is missing, the program will download the missing files.
Once the missing files are downloaded, the program will start automatically.
Note: Make sure you have an internet connection when you run the program for the first time.